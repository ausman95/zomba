@extends('layouts.app')

@section('content')
    <br>
<div class="container-fluid">

</div>
@endsection
