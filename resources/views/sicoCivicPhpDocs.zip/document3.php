<?php
include ('libs/fpdf184/fpdf.php');
include ("libs/numberToWords.php");

class order extends FPDF
{
    function my_header($customerArray){


        $this->SetFont('Arial','i',20);
        $this->Ln(10);

        $this->Image('libs/logo.jpg',198,-8,100);

        $this->SetFont('Arial','B',15);
        $this->SetFillColor(033,200,200);
        $this->Cell(24,10,' ',false,'','C',1);
        $this->Cell(184,10,'SICO CIVILS LTD ',false,'','C',1);
        $this->Ln();

        $this->SetFont('Arial','',10);
        $this->Cell(24,10,'BANK NAME',false,'','L',false);
        $this->Cell(44,10,@$customerArray['bankName'],1,'','L',false);
        $this->Cell(105,10,'',false,'','C',false);
        $this->Cell(35,10,@date('d/m/Y'),1,'','L',false);
        $this->Ln();

        $this->Cell(24,7,'CHEQUE NO',false,'','L',false);
        $this->Cell(44,7,@$customerArray['chequeNumber'],1,'','L',false);
        $this->Cell(105,7,'',false,'','C',false);
        $this->Cell(35,7,'',false,'','L',false);
        $this->Ln();

        $this->Cell(24,7,'ENTRY NO',false,'','L',false);
        $this->Cell(44,7,@$customerArray['entryNumber'],1,'','L',false);
        $this->Cell(105,7,'',false,'','C',false);
        $this->Cell(35,7,'',false,'','L',false);
        $this->Ln();

        $this->Cell(24,7,'INVOICE NO',false,'','L',false);
        $this->Cell(44,7,@$customerArray['invoiceNumber'],1,'','L',false);
        $this->Cell(75,7,'',false,'','C',false);
        $this->Cell(35,7,'',false,'','L',false);
        $this->Ln(10);

        $this->SetFont('Arial','B',11);
        $this->Cell(68,7,'Transaction Particulars',false,'','C',1);
        $this->Cell(223,7,'',false,'','C',1);
        $this->Ln();

        $this->Cell(68,10,'EXPENSE ACCOUNT/REFERENCE',1,'','C',false);
        $this->Cell(50,10,'CASH',1,'','C',false);
        $this->Cell(50,10,'CHEQUE',1,'','C',false);
        $this->Cell(123,10,'BANK TRANSFER',1,'','C',false);
        $this->Ln();

        $this->SetFont('Arial','B',8);
        $this->Cell(68,10,'',1,'','C');
        $this->Cell(25,10,'To Who',1,'','C',false);
        $this->Cell(25,10,'Amount',1,'','C',false);
        $this->Cell(25,10,'To Who',1,'','C',false);
        $this->Cell(25,10,'Amount',1,'','C',false);
        $this->Cell(23.6,10,'Name',1,'','C',false);
        $this->Cell(28.6,10,'Bank name & Branch',1,'','C',false);
        $this->Cell(23.6,10,'Acc No',1,'','C',false);
        $this->Cell(23.6,10,'Amount',1,'','C',false);
        $this->Cell(23.6,10,'Total Amount',1,'','C',false);
        $this->Ln();


    }

    function contents($data,$totalPaid=0){

        $totalAmount = 0;
        $total = 0;
        $this->SetFont('Arial','',8);

        foreach ($data as $key=>$values){

            $totalAmount += $values['totalAmount'];

            $this->Cell(68,10,$values['expenseAccount'],1,'','C');
            $this->Cell(25,10,$values['cashToWho'],1,'','C',false);
            $this->Cell(25,10,'MK'.number_format($values['cashToWhoAmount']),1,'','C',false);
            $this->Cell(25,10,$values['chequeToWho'],1,'','C',false);
            $this->Cell(25,10,'MK'.number_format($values['chequeToWhoAmount']),1,'','C',false);
            $this->Cell(23.6,10,$values['bankTransferBankName'],1,'','C',false);
            $this->Cell(28.6,10,$values['bankTransferBankNameAndBranch'],1,'','C',false);
            $this->Cell(23.6,10,$values['accountNumber'],1,'','C',false);
            $this->Cell(23.6,10,'MK'.number_format($values['amount']),1,'','C',false);
            $this->Cell(23.6,10,'MK'.number_format($values['totalAmount']),1,'','C',false);
            $this->Ln();
        }

        $this->SetFont('Arial','B',9);
        $this->Cell(68,10,'Total',1,'','C');
        $this->Cell(25,10,'',1,'','C',false);
        $this->Cell(25,10,'',1,'','C',false);
        $this->Cell(25,10,'',1,'','C',false);
        $this->Cell(25,10,'MK'.number_format($totalAmount),1,'','C',1);
        $this->Cell(23.6,10,'',1,'','C',false);
        $this->Cell(28.6,10,'',1,'','C',false);
        $this->Cell(23.6,10,'',1,'','C',false);
        $this->Cell(23.6,10,'',1,'','C',false);
        $this->Cell(23.6,10,'MK'.number_format($totalAmount),1,'','C',1);
        $this->Ln();

        $this->Cell(68,10,'Total In Words',false,'','C',1);
        $this->Cell(223,10,numberToWords($totalAmount),false,'','L',1);
        $this->Ln();
    }

    function footer_note($footerData){
        $this->Ln(8);
        $this->SetFont('Arial','B',10);
        $this->Cell(94.6,20,'PREPARED BY : '.$footerData['preparedBy'],'','','L','');
        $this->Cell(94.6,20,'CHECKED BY : '.$footerData['checkedBy'],'','','L','');
        $this->Cell(94.6,20,'APPROVED BY : '.$footerData['approvedBy'],'','','L','');
        $this->Ln(10);

        $this->Cell(94.6,20,'POSITION : '.$footerData['position'],'','','L','');
        $this->Cell(94.6,20,'POSITION : '.$footerData['checkedByPosition'],'','','L','');
        $this->Cell(94.6,20,'POSITION : '.$footerData['position2'],'','','L','');
        $this->Ln(10);

        $this->Cell(94.6,20,'SIGNATURE : ______________________','','','L','');
        $this->Cell(94.6,20,'SIGNATURE : ______________________','','','L','');
        $this->Cell(94.6,20,'SIGNATURE : ______________________','','','L','');
        $this->Ln(10);
    }
}
///////////////////////////SAMPLE DATA///////////////////////////////////////////////////////////////

$contents = [
    array(
        'expenseAccount'=>"Expense acc Name",
        'cashToWho'=>'Mr Clement',
        'cashToWhoAmount'=>12000,
        'chequeToWho'=>1000,
        'chequeToWhoAmount'=>1000,
        'bankTransferBankName'=>'NB',
        'bankTransferBankNameAndBranch'=>'NB Zomba',
        'accountNumber'=>23123,
        'amount'=>222233,
        'totalAmount'=>23123
    )
];

$preparedBy = "Clement";
$approvedBy = "Sakala";
$footerData = array(
    'preparedBy'=>'Kondwan Clement',
    'position'=>'Software Developer',
    'checkedBy'=>'Bosco Clement',
    'checkedByPosition'=>'Software Developer',
    'approvedBy'=>'Ausman Sakala',
    'position2'=>'Larvel Developer'
);

$headerData = array(
    'bankName'=>'Standard Bank',
    'chequeNumber'=>223,
    'entryNumber'=>2223,
    'invoiceNumber'=>222
);
///////////////////////////END OF SAMPLE DATA////////////////////////////////////////////////////////


$pdf = new order();
$pdf->SetMargins(2,5,2);
$pdf->AddPage('L','A4');
$pdf->AliasNbPages();
$pdf->my_header($headerData);
$pdf->contents($contents);
$pdf->footer_note($footerData);
@$pdf->Output();




